import 'package:flutter/material.dart';
import 'package:flutter_blue/flutter_blue.dart';

void main() => runApp(KrakenBLEControlApp());

class KrakenBLEControlApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Kraken BLE RGB Control',
      theme: ThemeData(primarySwatch: Colors.green),
      home: BluetoothScannerScreen(),
    );
  }
}

class BluetoothScannerScreen extends StatelessWidget {
  final FlutterBlue flutterBlue = FlutterBlue.instance;

  @override
  Widget build(BuildContext context) {
    flutterBlue.startScan(timeout: Duration(seconds: 5));

    return Scaffold(
      appBar: AppBar(title: Text('Kraken BLE Devices')),
      body: StreamBuilder<List<ScanResult>>(
        stream: flutterBlue.scanResults,
        builder: (c, snapshot) {
          if (!snapshot.hasData) return CircularProgressIndicator();
          var devices = snapshot.data!;
          return ListView(
            children: devices.map((r) {
              return ListTile(
                title: Text(r.device.name.isNotEmpty ? r.device.name : "Unknown"),
                subtitle: Text(r.device.id.toString()),
                onTap: () async {
                  await flutterBlue.stopScan();
                  await r.device.connect();
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (_) => DeviceControlScreen(device: r.device)),
                  );
                },
              );
            }).toList(),
          );
        },
      ),
    );
  }
}

class DeviceControlScreen extends StatefulWidget {
  final BluetoothDevice device;
  DeviceControlScreen({required this.device});

  @override
  _DeviceControlScreenState createState() => _DeviceControlScreenState();
}

class _DeviceControlScreenState extends State<DeviceControlScreen> {
  List<BluetoothService> services = [];

  @override
  void initState() {
    super.initState();
    widget.device.discoverServices().then((s) {
      setState(() {
        services = s;
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(widget.device.name)),
      body: ListView(
        children: services
            .expand((service) => service.characteristics)
            .map((c) => ListTile(
                  title: Text("Char: ${c.uuid}"),
                  subtitle: Text("Props: ${c.properties}"),
                  trailing: ElevatedButton(
                    child: Text("Send RGB OFF"),
                    onPressed: () async {
                      await c.write([0x00]); // Placeholder value to try
                    },
                  ),
                ))
            .toList(),
      ),
    );
  }
}
